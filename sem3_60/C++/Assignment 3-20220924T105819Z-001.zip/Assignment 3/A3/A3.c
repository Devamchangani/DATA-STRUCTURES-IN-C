/*
 * A3.c
 *
 *  Created on: 03-Sep-2022
 *      Author: root
 */




